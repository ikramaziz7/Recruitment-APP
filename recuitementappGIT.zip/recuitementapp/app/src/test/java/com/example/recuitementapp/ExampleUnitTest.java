package com.example.recuitementapp;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {

    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void emailValidation_CorrectEmailSimple_ReturnsTrue() {
        assertTrue(Validator.isValidEmail("test@example.com"));
    }

    @Test
    public void emailValidation_IncorrectEmail_ReturnsFalse() {
        assertFalse(Validator.isValidEmail("testexample.com"));
    }

    @Test
    public void emailValidation_EmptyEmail_ReturnsFalse() {
        assertFalse(Validator.isValidEmail(""));
    }

    @Test
    public void emailValidation_NullEmail_ReturnsFalse() {
        assertFalse(Validator.isValidEmail(null));
    }
}