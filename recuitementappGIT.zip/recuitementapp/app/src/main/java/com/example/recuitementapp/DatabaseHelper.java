package com.example.recuitementapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "UserManager.db";
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";

    private static final String TABLE_ANNONCE = "annonce";
    private static final String COLUMN_ANNONCE_ID = "annonce_id";
    private static final String COLUMN_TITRE = "titre";
    private static final String COLUMN_CATEGORIE = "categorie";
    private static final String COLUMN_SECTEUR = "secteur";
    private static final String COLUMN_CONTRAT = "contrat";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_VILLE = "ville";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    private static final String COLUMN_CITY = "city";
    private static final String COLUMN_ROLE = "role";
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," // Make sure ID autoincrements
                + COLUMN_EMAIL + " TEXT,"
                + COLUMN_PASSWORD + " TEXT,"
                + COLUMN_CITY + " TEXT,"
                + COLUMN_ROLE + " TEXT" + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_ANNONCE_TABLE = "CREATE TABLE " + TABLE_ANNONCE + "("
                + COLUMN_ANNONCE_ID + " INTEGER PRIMARY KEY,"
                + COLUMN_TITRE + " TEXT,"
                + COLUMN_CATEGORIE + " TEXT,"
                + COLUMN_SECTEUR + " TEXT,"
                + COLUMN_CONTRAT + " TEXT,"
                + COLUMN_DESCRIPTION + " TEXT,"
                + COLUMN_VILLE + " TEXT" + ")";
        db.execSQL(CREATE_ANNONCE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ANNONCE);
        onCreate(db);
    }

    public long addUser(String email, String password, String city, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, email);
        try {
            String hashedPassword = hashPassword(password);
            values.put(COLUMN_PASSWORD, hashedPassword);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return -1;
        }
        // Add city and role to the ContentValues
        values.put(COLUMN_CITY, city);
        values.put(COLUMN_ROLE, role);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result;
    }

    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE " +
                COLUMN_EMAIL + "=?", new String[]{email});
        boolean isAuthenticated = false;

        if (cursor.moveToFirst()) {
            int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);
            if (passwordIndex != -1) {
                String storedPassword = cursor.getString(passwordIndex);
                try {
                    isAuthenticated = hashPassword(password).equals(storedPassword);
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
        }
        cursor.close();
        return isAuthenticated;
    }


    public long addAnnonce(String titre, String categorie, String secteur, String contrat, String description, String ville) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITRE, titre);
        values.put(COLUMN_CATEGORIE, categorie);
        values.put(COLUMN_SECTEUR, secteur);
        values.put(COLUMN_CONTRAT, contrat);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_VILLE, ville);
        long result = db.insert(TABLE_ANNONCE, null, values);
        db.close();
        return result;
    }

    public int compterAnnoncesPourVille(String ville) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_ANNONCE + " WHERE " + COLUMN_VILLE + "=?", new String[]{ville});
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }


    private String hashPassword(String password) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(password.getBytes());
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
