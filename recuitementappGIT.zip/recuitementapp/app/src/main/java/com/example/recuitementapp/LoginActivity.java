package com.example.recuitementapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextEmail;
    private EditText editTextPassword;
    private Button buttonLogin;
    private CheckBox checkBoxKeepLoggedIn;
    private TextView textViewForgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cnx);

        // Initialize views
        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.confpassword);
        buttonLogin = findViewById(R.id.loginButton);
        checkBoxKeepLoggedIn = findViewById(R.id.checkbox_keep_logged_in);
        textViewForgotPassword = findViewById(R.id.tv_forgot_password);

        // Set click listeners
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        textViewForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                forgotPassword();
            }
        });
    }

    private void login() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        if (dbHelper.checkUser(email, password)) {
            // Navigate to MainActivity or another part of your app
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // Close the login activity
        } else {
            Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
        }
    }


    private void forgotPassword() {
        // Perform forgot password logic here
        // For demonstration purposes, just display a Toast message
        Toast.makeText(this, "Forgot password clicked", Toast.LENGTH_SHORT).show();
    }
}
