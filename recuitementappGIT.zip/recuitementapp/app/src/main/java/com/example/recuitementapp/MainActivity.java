package com.example.recuitementapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextTitre;
    private Spinner spinnerCategorie;
    private Spinner spinnerSecteur;
    private EditText editTextContrat;
    private EditText editTextDescription;
    private Spinner spinnerCity;
    private Button buttonSubmit;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.deposerannon);

        dbHelper = new DatabaseHelper(this);

        // Initialisation des vues
        editTextTitre = findViewById(R.id.titre);
        spinnerCategorie = findViewById(R.id.catSpinner);
        spinnerSecteur = findViewById(R.id.secteurSpinner);
        editTextContrat = findViewById(R.id.contrat);
        editTextDescription = findViewById(R.id.description);
        spinnerCity = findViewById(R.id.citySpinner);
        buttonSubmit = findViewById(R.id.Next);

        // Définir les options pour le spinner "City"
        List<String> cityList = Arrays.asList("Casablanca", "Agadir", "Tanger", "Rabat", "Fes");
        ArrayAdapter<String> cityAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, cityList);
        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCity.setAdapter(cityAdapter);

        // Définir les options pour le spinner "Secteur"
        List<String> secteurList = Arrays.asList("Technologies de l'information et des communications (TIC)", "Vente au détail", "Services financiers", "Ressources Humaines", "Santé et bien-être", "Éducation et formation", "Fabrication", "Tourisme et hôtellerie");
        ArrayAdapter<String> secteurAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, secteurList);
        secteurAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSecteur.setAdapter(secteurAdapter);

        // Définir les options pour le spinner "Catégorie"
        List<String> categorieList = Arrays.asList("Informatique et Technologies", "Ventes et Marketing", "Finance et Comptabilité", "Ressources Humaines", "Service à la clientèle", "Administration et Secrétariat", "Ingénierie", "Santé et Services sociaux");
        ArrayAdapter<String> categorieAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, categorieList);
        categorieAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCategorie.setAdapter(categorieAdapter);

        // Ajout d'un écouteur de clic pour le bouton
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Appel de la méthode pour gérer le clic sur le bouton
                handleSubmitButtonClick();
            }
        });
    }

    // Méthode pour gérer le clic sur le bouton de soumission
    // Méthode pour gérer le clic sur le bouton de soumission
    private void handleSubmitButtonClick() {
        // Récupérer les valeurs des champs
        String titre = editTextTitre.getText().toString();
        String categorie = spinnerCategorie.getSelectedItem().toString();
        String secteur = spinnerSecteur.getSelectedItem().toString();
        String contrat = editTextContrat.getText().toString();
        String description = editTextDescription.getText().toString();
        String city = spinnerCity.getSelectedItem().toString();

        // Ajouter l'annonce à la base de données
        long result = dbHelper.addAnnonce(titre, categorie, secteur, contrat, description, city);
        if (result != -1) {
            Toast.makeText(this, "Annonce ajoutée avec succès", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Erreur lors de l'ajout de l'annonce", Toast.LENGTH_SHORT).show();
        }
    }

}
