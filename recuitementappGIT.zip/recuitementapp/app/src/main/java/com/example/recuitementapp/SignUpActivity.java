package com.example.recuitementapp;

import android.util.Patterns;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.CheckBox;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.TextView;
import android.content.Intent;
import android.view.View;


public class SignUpActivity extends AppCompatActivity {

    private EditText editTextEmail;
    private Spinner spinnerCity;
    private EditText editTextPassword;
    private EditText editTextConfirmPassword;
    private RadioGroup radioGroupRole;

    // Instance of DatabaseHelper
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup1);

        CheckBox checkBoxShowPassword = findViewById(R.id.checkBoxShowConfirmPassword);
        editTextPassword = findViewById(R.id.mdp);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);

        checkBoxShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // Show passwords
                editTextPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                editTextConfirmPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
            } else {
                // Hide passwords
                editTextPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                editTextConfirmPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
            }
            editTextPassword.setSelection(editTextPassword.getText().length());
            editTextConfirmPassword.setSelection(editTextConfirmPassword.getText().length());
        });




        // Initialize DatabaseHelper
        dbHelper = new DatabaseHelper(this);

        // Initialize views
        editTextEmail = findViewById(R.id.email);
        spinnerCity = findViewById(R.id.citySpinner);
        editTextPassword = findViewById(R.id.mdp);
        editTextConfirmPassword = findViewById(R.id.editTextConfirmPassword);
        Button buttonSignUp = findViewById(R.id.Signup);
        radioGroupRole = findViewById(R.id.radioGroupRole);

        // Populate the Spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.city_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerCity.setAdapter(adapter);

        // Set click listener for sign up button
        buttonSignUp.setOnClickListener(v -> signUp());

        TextView textViewAlreadyHaveAccount = findViewById(R.id.textViewAlreadyHaveAccount);
        textViewAlreadyHaveAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to LoginActivity
                Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }

    // Method to handle sign up process
    private void signUp() {
        // Get values from views
        String email = editTextEmail.getText().toString();
        Object selectedItem = spinnerCity.getSelectedItem();
        String city = selectedItem != null ? selectedItem.toString() : "";
        String password = editTextPassword.getText().toString();
        String confirmPassword = editTextConfirmPassword.getText().toString();
        int selectedRoleId = radioGroupRole.getCheckedRadioButtonId();
        String role = "";

        // Determine selected role
        if (selectedRoleId == R.id.radioRecruiter) {
            role = getString(R.string.recruiter);
        } else if (selectedRoleId == R.id.radioCandidate) {
            role = getString(R.string.candidate);
        }

        // Validate input fields
        if (validateInputs(email, city, password, confirmPassword)) {
            // Check if user already exists
            if (!dbHelper.checkUser(email, password)) {
                // Add user to database
                long userId = dbHelper.addUser(email, password, city, role);

                if (userId != -1) {
                    // User registration successful
                    Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show();
                } else {
                    // User registration failed
                    Toast.makeText(this, "Failed to register user!", Toast.LENGTH_SHORT).show();
                }
            } else {
                // User already exists
                Toast.makeText(this, "User already exists!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Method to validate input fields
    private boolean validateInputs(String email, String city, String password, String confirmPassword) {
        // Regular expression for password validation
        String passwordPattern = "^(?=.*[A-Z]).{6,}$";

        if (email.isEmpty() || city.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return false;
        } else if (!password.matches(passwordPattern)) {
            Toast.makeText(this, "Password must be at least 6 characters and include at least one capital letter.", Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
}
